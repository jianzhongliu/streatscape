//
//  BusRouteSearchViewControllerDemo.m
//  SOSOMapAPIDemo
//
//  Created by wei lv on 12-8-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "BusRouteSearchViewControllerDemo.h"

@interface BusRouteSearchViewControllerDemo ()

- (void)showAlertView:(NSString*)title widthMessage:(NSString*)message;

@end

@implementation BusRouteSearchViewControllerDemo
@synthesize mapView = _mapView;
@synthesize search = _search;

//- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
//{
//    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
//    if (self) {
//        // Custom initialization
//    }
//    return self;
//}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    _mapView.delegate = self;
    
    QSearch* search = [[QSearch alloc] init];
    search.delegate = self;
    self.search = search;
    [search release];
    [_search busSearch:@"北京市" start:@"北京南站" 
                   end:@"银科大厦" withBusSearchType:QBusSearchShortCut];
}

- (void)notifyRouteSearchResult:(QRouteSearchResult *)routeSearchResult
{
    QErrorCode errCode = [routeSearchResult errorCode];
    NSLog(@"get bus res %i",errCode);
    if (errCode == QRouteSearchResultBusList) {
        
        NSMutableString* msg = [[NSMutableString alloc] init];
        [msg appendString:@"start:\n"];
        
        QRouteQueryResultChoice* choice = (QRouteQueryResultChoice*)[routeSearchResult data];
        
        NSInteger count = 0;
        for (QPlaceInfo* info in [choice startList]) {
            
            [msg appendFormat:@"%d.name=%@,address=%@,coor={%lf,%lf}\n",count,
             info.name,info.address,info.coordinate.longitude,info.coordinate.latitude];
            ++count;
        }
        
        [msg appendString:@"end:\n"];
        
        count = 0;
        for (QPlaceInfo* info in [choice endList]) {
            
            [msg appendFormat:@"%d.name=%@,address=%@,coor={%lf,%lf}\n",
             count,info.name,info.address,info.coordinate.longitude,info.coordinate.latitude];
            ++count;
        }
        
        [self showAlertView:@"choice list" widthMessage:msg];
        [msg release];
        
        /*
        出现选择列表，可以选取完起终点再进行进一步搜索，类似下述做法
       */
        NSArray* startList = choice.startList;
        NSArray* endList = choice.endList;
      
        if (startList.count > 0 && endList.count > 0 ) {
            [_search busSearchWithLocation:@"北京"
                                     start:  [startList objectAtIndex:0]
                                       end:[endList objectAtIndex:0]
                         withBusSearchType:QBusSearchShortCut];
        }
        
    }
    else if (errCode == QRouteSearchResultBusResult) {
        
        QRoutePlan* plan = [routeSearchResult data];
        
        QPointAnnotation* pa = [[QPointAnnotation alloc] init];
        pa.coordinate = plan.start.coordinate;
        pa.title = [NSString stringWithFormat:@"起点:%@",plan.start.name];
        [_mapView addAnnotation:pa];
        [pa release];
        
        pa = [[QPointAnnotation alloc] init];
        pa.coordinate = plan.end.coordinate;
        pa.title = [NSString stringWithFormat:@"终点:%@",plan.end.name];
        [_mapView addAnnotation:pa];
        [pa release];
        
        NSArray* routeList = [plan routeInfoList];
        
        for (QRouteInfoForBus* route in routeList) {
            
            QPolyline* pl = [QPolyline polylineWithCoordinates:route.routeNodeList
                                                         count:route.routeNodeCount];
            [_mapView addOverlay:pl];
            
            _mapView.region = QCoordinateRegionMake( _mapView.centerCoordinate, QCoordinateSpanMake(0.1, 0.1));
            
            break;
        }
    }
}

- (QAnnotationView *)mapView:(QMapView *)mapView viewForAnnotation:(id <QAnnotation>)annotation
{
	if ([annotation isKindOfClass:[QPointAnnotation class]]) {
        static NSString* reuseIdentifier = @"annotation";
        
        QPinAnnotationView* newAnnotation = (QPinAnnotationView*)[_mapView dequeueReusableAnnotationViewWithIdentifier:reuseIdentifier];
        
        if (nil == newAnnotation) {
            newAnnotation = [[[QPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:reuseIdentifier] autorelease]; 
        }
        
		newAnnotation.pinColor = QPinAnnotationColorRed;   
		newAnnotation.animatesDrop = YES;
        newAnnotation.canShowCallout = YES;
		
		return newAnnotation;   
	}
	return nil;
}

-(QOverlayView*)mapView:(QMapView *)mapView viewForOverlay:(id<QOverlay>)overlay
{
    if ([overlay isKindOfClass:[QPolyline class]]) {
        
        QPolylineView* polylineView = [[QPolylineView alloc] initWithPolyline:overlay];
        
        polylineView.lineWidth = 2.0;
		polylineView.strokeColor =  [UIColor purpleColor];//[[UIColor redColor] colorWithAlphaComponent:0.5];
        
        return [polylineView autorelease];
    }
    
    return nil;
    
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
    _mapView.delegate = nil;
    self.mapView = nil;
    _search.delegate = nil;
    self.search = nil;
    
}


- (void)dealloc
{
    _mapView.delegate = nil;
    self.mapView = nil;
    _search.delegate = nil;
    self.search = nil;
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)showAlertView:(NSString*)title widthMessage:(NSString*)message
{
    UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:title 
                                                        message:message 
                                                       delegate:nil 
                                              cancelButtonTitle:@"OK" 
                                              otherButtonTitles:nil];
    [alertView sizeToFit];
	[alertView show];
	[alertView release];
}


@end
